#!/bin/bash

while getopts "t:a:i:p:h" arg;
do
    case $arg in
        t)
            TYPE=$OPTARG
            ;;
        a)
            ADDR=$OPTARG
            ;;
        i)
            IP=$OPTARG
            ;;
        p)
            UDPPORT=$OPTARG
            ;;
        h)
            echo -e "-t: 申明节点注册类型"
            echo -e "-a: 指定节点账号地址"
            echo -e "-i: 给节点程序分配的IP，127.0.0.x，不能和已启动的节点程序冲突"
            echo -e "-p: 给节点程序分配的UDP端口，主机上任一未被占用的端口即可\n"
            exit 0
            ;;
        ?)
            echo "unexpect param!"
            exit -1
            ;;
    esac
done

SCRIPT_DIR=$(dirname $0)
CONVERT_SH=${SCRIPT_DIR}/convert
TOPIO_HOME_ENV=$(echo $TOPIO_HOME)
CONFIG_DIR=${TOPIO_HOME_ENV}/config
XTOPCHAIN=${TOPIO_HOME_ENV}/xtopchain
NODE_ADDRESS_FILE=${TOPIO_HOME_ENV}/keystore/${ADDR}

if [ -z ${TOPIO_HOME_ENV} ];then
    echo "WARN TOPIO_HOME not set"
elif [ ! -d ${TOPIO_HOME_ENV} ];then
    echo "TOPIO_HOME("${TOPIO_HOME_ENV}") invalid"
    exit -1
else 
    echo "using TOPIO_HOME="${TOPIO_HOME_ENV}
fi

if [ ! -f ${CONVERT_SH} ];then
    echo "CONVERT FILE("${CONVERT_SH}") no found"
    exit -1
fi

if [ ! -f ${XTOPCHAIN} ];then
    echo "XTOPCHAIN FILE("${XTOPCHAIN}") no found"
    exit -1
fi

if [ ! -d ${CONFIG_DIR} ];then
    echo "CONFIG DIR("${CONFIG_DIR}") no found"
    exit -1
fi

if [ ! -f ${NODE_ADDRESS_FILE} ];then
    echo "NODE KEYSTORE FILE("${NODE_ADDRESS_FILE}") no found"
    exit -1
fi

if [ -z ${TYPE} ];then
    echo "NODE TYPE("${TYPE}") invalid"
    exit -1
fi

if [ -z ${IP} ];then
    echo "NODE IP("${IP}") invalid"
    exit -1
fi

if [ -z ${UDPPORT} ];then
    echo "NODE UDP PORT("${UDPPORT}") invalid"
    exit -1
fi

WORK_DIR=/tmp/${TYPE}_${ADDR}
PUBK=$(jq -r .public_key ${NODE_ADDRESS_FILE})
PRIK=$(${CONVERT_SH} ${NODE_ADDRESS_FILE})
CONFIG_FILE=${CONFIG_DIR}/config.${ADDR}.json

echo "WORK DIR: ${WORK_DIR}"
if [ -d ${WORK_DIR} ];then
    rm -fr ${WORK_DIR}
fi
mkdir -p ${WORK_DIR}/db
mkdir -p ${WORK_DIR}/log

cat > ${CONFIG_FILE} << EOF
{
   "ip" : "${IP}",
   "db_path" : "${WORK_DIR}/db",
   "log_path" : "${WORK_DIR}/log",
   "log_level" : 0,
   "grpc_port" : 19082,
   "http_port" : 19081,
   "ws_port" : 19085,
   "node_type" : "${TYPE}",
   "node_id" : "${ADDR}",
   "public_key" : "${PUBK}",
   "sign_key" : "${PRIK}",
   "min_auditor_group_size" : 3,
   "max_auditor_group_size" : 3,
   "min_validator_group_size" : 3,
   "max_validator_group_size" : 3,
   "min_election_committee_size" : 6,
   "max_election_committee_size" : 6,
   "auditor_group_count" : 1,
   "validator_group_count" : 1,
   "rec_election_interval" : 181,
   "zec_election_interval" : 211,
   "zone_election_trigger_interval" : 5,
   "cluster_election_interval" : 71,
   "edge_election_interval" : 9,
   "archive_election_interval" : 11,
   "genesis" : {
      "accounts" : {
         "tcc": {
            "T00000LcxcHVTKki5KqCKmX5BbbMSGrUPhTEpwnu": {"balance": "1000000000"},
            "T00000LfazE9WjtUu4xx5caD9w9dWwiRGggHxxvo": {"balance": "1000000000"},
            "T00000LfyErVp716mVR89UdJMQaZJ6W9Hv7NsHT4": {"balance": "1000000000"}
        },
        "genesis_funds_account": {
            "T00000Lhj29VReFAT958ZqFWZ2ZdMLot2PS5D5YC": {"balance": "2999997000000000"},
            "T00000LhPZXie5GqcZqoxu6BkfMUqo7e9x1EaFS6": {"balance": "6000000000000000"},
            "T00000LKMWBfiHPeN9TShPdB9ctLDr7mmcZa46Da": {"balance": "3400000000000000"}
        }
      },
      "seedNodes" : {
         "T00000LKy8CAPRETJmUr9DZiwCPcc9VFqDBpQEG6" : "BO1GzXnnDufgfv/OYyBGA4b/cgq87H3F0tCkeQiR5b4mePf8V721WoXPHGgvWPdQ2Ci0SsL4VSrSLVdKeheNdyk=",
         "T00000LLLK8teSrpbtcVnaYCtykniJHHeMZegQMU" : "BHWT6Jr004YIsfnhtUkLl2ZK7Z6gxfhaktgxib+8dKlOhqkTxib0bMQKtrjuKHQWVE2DaEF7QQiMWUeF9mEt59E=",
         "T00000LPjk6KqsnCu46kHffttVPjToRmitpStvvo" : "BKnMfrDLOw2tyuCBK7Fqa+pHp4o8/fQKLVN8EPGxkzEy2wz6rjR2TrKasn2m0R7yEEa1DM3iCjOwyAxiq3eAdcQ=",
         "T00000LQkSo2PYR7hVxZmkQphvsxAbiB8V22PwPT" : "BJE+S/NmkfMB8OIzHoJcy+lrBs0yD7X0dbKmYTg4PaNzLpaPIG9x5ojAJjSDm4JzpE84YN2C09nenWtJo0Qqxx4=",
         "T00000LRauRZ3SvMtNhxcvoHtP8JK9pmZgxQCe7Q" : "BBZQTi7Pv4yRCYzFxri1BRUWXV6hd3nXG1tV21niKRfhk9sPmqX5SA1PcPhe3ZECIILpuvceiguSh6arX6Wfd0k=",
         "T00000LRc5LxEXVdUuFcoLezjPiMw4CLYgvkEmtC" : "BAR31Ok8x+EXZIMJNhQhgHXdvEfbJJ6EajJn0OZf0jPC3NKzyAAmTP86LPwATfeE+KyZUFom5tdCErx4ThlgQ4Q="
      },
      "timestamp": 1599555555
   },
   "platform" : {
      "business_port" : ${UDPPORT},
      "url_endpoints": "http://unnecessary.org",
      "public_endpoints" : "127.0.0.1:9001,127.0.0.2:9002,127.0.0.3:9003,127.0.0.4:9004,127.0.0.5:9005,127.0.0.6:9006"
   }
}
EOF

echo "start"
cd ${TOPIO_HOME_ENV} && ulimit -c unlimited && ./xtopchain ${CONFIG_FILE} > /dev/null 2>&1 &

if [ $? -ne 0 ];then
    echo "start node failed"
    exit -1
fi

echo "finish"