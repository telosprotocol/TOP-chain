#!/bin/bash

while getopts "j:x:t:a:i:h" arg;
do
    case $arg in
        j)
            TJSON=$OPTARG
            ;;
        x)
            TOP_FILE=$OPTARG
            ;;
        t)
            TYPE=$OPTARG
            ;;
        a)
            ADDR=$OPTARG
            ;;
        i)
            IP=$OPTARG
            ;;
        h)
            echo -e "-j: 指定拓扑文件绝对路径"
            echo -e "-x: 指定部署的xtopchain程序包绝对路径"
            echo -e "-t: 申明节点注册类型"
            echo -e "-a: 指定节点账号地址"
            echo -e "-i: 指定新节点主机IP\n"
            exit 0
            ;;
        ?)
            echo "unexpect param!"
            exit -1
            ;;
    esac
done

echo -e "\n============================================================"
date
echo "[TRACE] >>> Verify XTOPCHAIN & HOSTS"

SCRIPT_DIR=$(dirname $0)
CONVERT_SH=${SCRIPT_DIR}/convert
TOPIO_HOME_ENV=$(echo $TOPIO_HOME)
XTOPCHAIN=${TOPIO_HOME_ENV}/xtopchain
NODE_ADDRESS_FILE=${TOPIO_HOME_ENV}/keystore/${ADDR}
WORK_DIR=${TOPIO_HOME_ENV}/workdir
RUNFILE=${WORK_DIR}/run_normal.yml
COPYFILE=${WORK_DIR}/dispense.yml
HOST_FILE=${WORK_DIR}/host.${ADDR}
CONFIG_FILE=${WORK_DIR}/${IP}.config

if [ -z ${TOPIO_HOME_ENV} ];then
    echo "WARN TOPIO_HOME not set"
elif [ ! -d ${TOPIO_HOME_ENV} ];then
    echo "TOPIO_HOME("${TOPIO_HOME_ENV}") invalid"
    exit -1
else 
    echo "using TOPIO_HOME="${TOPIO_HOME_ENV}
fi

if [ ! -f "$TJSON" ];then
	echo "TJSON ("${TJSON}") no exist!"
 	exit -1
fi

if [ ! -f "$TOP_FILE" ];then
	echo "TOP FILE ("${TOP_FILE}") no exist!"
 	exit -1
fi
CHAIN_FILE=$(basename ${TOP_FILE})
XTOP_TAR_FILE=${WORK_DIR}/${CHAIN_FILE}.tar.gz

if [ ! -f ${NODE_ADDRESS_FILE} ];then
    echo "NODE KEYSTORE FILE("${NODE_ADDRESS_FILE}") no found"
    exit -1
fi

if [ -z ${TYPE} ];then
    echo "NODE TYPE("${TYPE}") invalid"
    exit -1
fi

if [ -z ${IP} ];then
    echo "NODE IP("${IP}") invalid"
    exit -1
fi


cd ${TOPIO_HOME_ENV}
PUBK=$(jq -r .public_key ${NODE_ADDRESS_FILE})
PRIK=$(${CONVERT_SH} ${NODE_ADDRESS_FILE})

TRAGET_GROUP="all"

if [[ ! -d ${WORK_DIR} ]];then
    mkdir -p ${WORK_DIR}
fi

# get host auth
authName=$(jq -r ".connect.username" $TJSON)
authPort=$(jq -r ".connect.port" $TJSON)
authPawd=$(jq -r ".connect.password" $TJSON)

cd ${WORK_DIR}

# fix all
cat > ${HOST_FILE} << EOF
[all]
EOF

cat >> ${HOST_FILE} << EOF
$IP ansible_ssh_user=$authName ansible_ssh_pass=$authPawd ansible_ssh_port=$authPort
EOF

echo "[TRACE] >>> Verify PASS"

echo -e "\n============================================================"
date
echo "[TRACE] >>> Prepare CONFIG and YML FILEs"

recNodes=''
rec_count=$(jq -r ".public.max_election_committee_size" $TJSON)
for i in $(seq 1 $rec_count);do
  let j="$i-1"
  rec_pubkey=$(jq -r ".rec|.[$j].pubkey" $TJSON)
  rec_account=$(jq -r ".rec|.[$j].account" $TJSON)
  recNodes=${recNodes}"\""${rec_account}"\":\""${rec_pubkey}"\","
done
recNodes=${recNodes%?}

pubEndPoints=''
busPort=$(jq -r ".public.BusPort" $TJSON)
rec_count=$(jq -r ".public.max_election_committee_size" $TJSON)
let rec_count_part="${rec_count}-3"
for i in $(seq 1 $rec_count_part);do
  let j="$i-1"
  rec_host=$(jq -r ".rec|.[$j].host" $TJSON)
  pubEndPoints=${pubEndPoints}${rec_host}":"${busPort}","
done
pubEndPoints=${pubEndPoints%?}

httpPort=$(jq -r ".public.httpPort" $TJSON)
grpcPort=$(jq -r ".public.grpcPort" $TJSON)
wsPort=$(jq -r ".public.wsPort" $TJSON)
busPort=$(jq -r ".public.BusPort" $TJSON)
recEleInt=$(jq -r ".public.rec_election_interval" $TJSON)
zecEleInt=$(jq -r ".public.zec_election_interval" $TJSON)
zoneEleInt=$(jq -r ".public.zone_election_trigger_interval" $TJSON)
comMinSize=$(jq -r ".public.min_election_committee_size" $TJSON)
comMaxSize=$(jq -r ".public.max_election_committee_size" $TJSON)
clsEleInt=$(jq -r ".public.cluster_election_interval" $TJSON)
advClsCount=$(jq -r ".public.auditor_group_count" $TJSON)
conClsCount=$(jq -r ".public.validator_group_count" $TJSON)
advMinSize=$(jq -r ".public.min_auditor_group_size" $TJSON)
advMaxSize=$(jq -r ".public.max_auditor_group_size" $TJSON)
conMinSize=$(jq -r ".public.min_validator_group_size" $TJSON)
conMaxSize=$(jq -r ".public.max_validator_group_size" $TJSON)
logLevel=$(jq -r ".public.logLevel" $TJSON)
TARGET_DIR=$(jq -r ".public.workdir" $TJSON)
DB_FOLDER=$(jq -r ".public.dbPath" $TJSON)
PDB_FOLDER=$(jq -r ".public.pdbPath" $TJSON)
LOG_FOLDER=$(jq -r ".public.logPath" $TJSON)
DB_DIR=${TARGET_DIR}/${DB_FOLDER}
LOG_DIR=${TARGET_DIR}/${LOG_FOLDER}

# fix config
cat > ${CONFIG_FILE} << EOF
{
  "ip": "${IP}",
  "node_id": "${ADDR}",
  "http_port": ${httpPort},
  "grpc_port": ${grpcPort},
  "ws_port": ${wsPort},
  "log_level": ${logLevel},
  "log_path": "${LOG_DIR}",
  "db_path": "${DB_DIR}",
  "node_type": "${TYPE}",
  "public_key": "${PUBK}",
  "sign_key": "${PRIK}",
  "auditor_group_count":${advClsCount},
  "validator_group_count":${conClsCount},
  "min_election_committee_size":${comMinSize},
  "max_election_committee_size":${comMaxSize},
  "min_auditor_group_size":${advMinSize},
  "max_auditor_group_size":${advMaxSize},
  "min_validator_group_size":${conMinSize},
  "max_validator_group_size":${conMaxSize},
  "rec_election_interval":${recEleInt},
  "zec_election_interval":${zecEleInt},
  "zone_election_trigger_interval":${zoneEleInt},
  "cluster_election_interval":${clsEleInt},
  "edge_election_interval":9,
  "archive_election_interval":11,
  "genesis": {
        "accounts" : {
            "tcc": {
                "T00000LcxcHVTKki5KqCKmX5BbbMSGrUPhTEpwnu": {"balance": "1000000000"},
                "T00000LfazE9WjtUu4xx5caD9w9dWwiRGggHxxvo": {"balance": "1000000000"},
                "T00000LfyErVp716mVR89UdJMQaZJ6W9Hv7NsHT4": {"balance": "1000000000"}
            },
            "genesis_funds_account": {
                "T00000Lhj29VReFAT958ZqFWZ2ZdMLot2PS5D5YC": {"balance": "2999997000000000"},
                "T00000LhPZXie5GqcZqoxu6BkfMUqo7e9x1EaFS6": {"balance": "6000000000000000"},
                "T00000LKMWBfiHPeN9TShPdB9ctLDr7mmcZa46Da": {"balance": "3400000000000000"}
            }
        },
        "seedNodes": {${recNodes}},
        "timestamp": 1599555555
    },
  "platform":{
    "business_port": ${busPort},
    "url_endpoints": "http://unnecessary.org",
    "public_endpoints": "${pubEndPoints}"
  }
}
EOF

cat > dispense.yml << EOF
---
- hosts: "{{ host }}"
  tasks:
  - copy:
      src: "${WORK_DIR}/{{ inventory_hostname }}.config"
      dest: ${TARGET_DIR}/config.json
EOF

cat > run_normal.yml << EOF
---
- hosts: "{{ host }}"
  remote_user: root
  tasks:
  - name: run xtop
    shell: "(ulimit -c unlimited && export GLIBCXX_FORCE_NEW=1 && cd ${TARGET_DIR} && ./${CHAIN_FILE} config.json > /dev/null 2>&1 &)"
    async: 8
    poll: 0
EOF

echo -e "\n============================================================"
date
echo "[TRACE] >>> CLEAN HOSTS PROCESS"

ansible -i ${HOST_FILE} ${TRAGET_GROUP} -m shell -a "ps -ef|grep '[.]/${CHAIN_FILE}' | grep -v '/dev/null' | awk '{print \$2}' | xargs -I {} bash -c 'if \[ ! -z {} \] ;then kill -9 {} ;fi;'"

echo -e "\n============================================================"
date
echo "[TRACE] >>> CLEAN HOSTS WORK FOLDER"

ansible -i ${HOST_FILE} ${TRAGET_GROUP} -m file -a "path=${TARGET_DIR} state=absent"

echo -e "\n============================================================"
date
echo "[TRACE] >>> CREATE HOSTS WORK FOLDER"

ansible -i ${HOST_FILE} ${TRAGET_GROUP} -m file -a "path=${TARGET_DIR} state=directory"
ansible -i ${HOST_FILE} ${TRAGET_GROUP} -m file -a "path=${DB_DIR} state=directory"
ansible -i ${HOST_FILE} ${TRAGET_GROUP} -m file -a "path=${LOG_DIR} state=directory"

echo -e "\n============================================================"
date
echo "[TRACE] >>> Dispath XTOPCHAIN"

cp $TOP_FILE ${WORK_DIR}/${CHAIN_FILE}
if [ -f ${XTOP_TAR_FILE} ];then
    rm -f ${XTOP_TAR_FILE}
fi
tar -zcvf ${CHAIN_FILE}.tar.gz ${CHAIN_FILE}
ansible -i ${HOST_FILE} ${TRAGET_GROUP} -m unarchive -a "src=${XTOP_TAR_FILE} dest=${TARGET_DIR} mode=0755 copy=yes"
if [[ $? -ne 0 ]];then
    echo 'ansible dispath xtopchain failed'
    exit -1
fi

echo -e "\n============================================================"
date
echo "[TRACE] >>> Dispense CONFIG FILEs"

# transfer config
ansible-playbook -i ${HOST_FILE} -e host=${TRAGET_GROUP} ${COPYFILE}
if [[ $? -ne 0 ]];then
    echo "dispense config failed!"
    exit -1
fi

echo -e "\n============================================================"
date
echo "[TRACE] >>> CHECK CONFIG FILEs"

ansible -i ${HOST_FILE} ${TRAGET_GROUP} -m shell -a "ls ${TARGET_DIR}/config.json"
if [[ $? -ne 0 ]];then
  echo "some node can not dispense config.json!"
  exit -1
fi

echo -e "\n============================================================"
date
echo "[TRACE] >>> START NODE"

# run node
ansible-playbook -i ${HOST_FILE} -e host=${TRAGET_GROUP} ${RUNFILE} 
sleep 60

ansible -i ${HOST_FILE} ${TRAGET_GROUP} -m shell -a "ps -ef|grep '[.]/${CHAIN_FILE}'|grep -v dev|awk '{print \$2}'|sort -nr|head -n1|xargs -I {} bash -c 'netstat -anop|grep {}'"
stat=$(ansible -i ${HOST_FILE} ${TRAGET_GROUP} -m shell -a "ps -ef|grep '[.]/${CHAIN_FILE}'|grep -v dev")

# echo $stat
ret=$(echo $stat|grep -o FAILED|wc -l)
if [ $ret -gt 0 ];then
    echo -e "\n============================================================"
    date
    echo "[TRACE] >>> XTOPCHAIN DEPLOY FAILED"
    echo 'node down sum: '$ret
    echo $stat|sed 's#>>#\n#g'|grep FAILED
    exit -1
fi

echo -e "\n============================================================"
date
echo "[TRACE] >>> XTOPCHAIN DEPLOY SUCCESS"



